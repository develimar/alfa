<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Tópicos:</h1>
<ul>
    <li><a href="">Introdução</a></li>
    <li><a href="">O que é SEO</a></li>
    <li><a href="#topico3">Como otimizar seus site</a></li>
</ul>

<div>
    <h2>Como otimizar seu site</h2>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    <div id="topico3">    <p>Escolher um livro de marketing digital para ler e aumentar os conhecimentos sobre o assunto nem sempre é tão fácil assim. Livros existem muitos, mas bons, simples e diretos… nem tanto!</p>
    </div>
</div>

</body>
</html>