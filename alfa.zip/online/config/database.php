<?php if (__FILE__ == $_SERVER['SCRIPT_FILENAME']) exit('No direct access allowed.');

$config['db_hostname'] = '__DB_HOSTNAME__';
$config['db_username'] = '__DB_USERNAME__';
$config['db_password'] = '__DB_PASSWORD__';
$config['db_name'] = '__DB_NAME__';
$config['db_driver'] = 'mysql';
$config['db_charset'] = 'utf8';
$config['table_prefix'] = '__TABLE_PREFIX__';

?>
