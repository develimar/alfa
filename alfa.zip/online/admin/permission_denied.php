<?php 

//Include the common file
require_once('../common.php');

//Include the administration file
require_once('admin.php');

//Display the template
$tpl->display('admin/permission_denied');

?>
