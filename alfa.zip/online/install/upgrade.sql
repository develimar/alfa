INSERT INTO __TABLE_PREFIX__options (option_name, option_value) VALUES('max_visitors', 15);
INSERT INTO __TABLE_PREFIX__options (option_name, option_value) VALUES('background_color_3', '#006DCC');
INSERT INTO __TABLE_PREFIX__options (option_name, option_value) VALUES('color_3', '#FFFFFF');
